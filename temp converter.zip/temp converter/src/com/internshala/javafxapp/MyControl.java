package com.internshala.javafxapp;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.ResourceBundle;

public class MyControl implements Initializable {

    @FXML
    public Label welcomelabel;
    @FXML
    public ChoiceBox<String> choicebox;
    @FXML
    public TextField userinput;
    @FXML
    public Button convertbutton;
    private static final String c2f = "Celsius to Fahrenheit";
    private static final String f2c = "Fahrenheit to Celsius";
    private boolean isc2f = true;

    @Override
    public void initialize(URL location, ResourceBundle resources) {


        choicebox.getItems().add(c2f);
        choicebox.getItems().add(f2c);

        choicebox.setValue(c2f);

        choicebox.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue.equals(c2f)){
                isc2f=true;
            }
            else isc2f = false;
        });
        convertbutton.setOnAction(event -> {
            convert();
        });
    }

    private void convert() {
        String inp = userinput.getText();
        float enteredtemp = 0.0f;
        try{
             enteredtemp = Float.parseFloat(inp);
        }
        catch(Exception exc)
        {
            warnUser();
            return;
        }
        float newtemp = 0.0f;
        if(isc2f){
            newtemp = (enteredtemp*9/5)+32;
        }
        else newtemp = (enteredtemp-32)*5/9;
        display(newtemp);
    }

    private void warnUser() {
        Alert alert1 = new Alert(Alert.AlertType.ERROR);
        alert1.setTitle("Error Occured!");
        alert1.setHeaderText("Invalid temperature has been entered!");
        alert1.setContentText("Please enter a valid temperature.");
        alert1.show();
    }

    private void display(float newtemp) {
        String unit = isc2f? "F":"C";
        System.out.println("The new temperature is: "+newtemp+" "+unit);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Result");
        alert.setContentText("The new temperature is: "+ newtemp + unit);
        alert.show();
    }
}
